#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''auto created template to create a custom ETL for yatel'''

import collections
import itertools
import json
import time
import csv

from yatel import etl, dom, weight


#==============================================================================
# CACHE
#==============================================================================

class DoubleDictCache(collections.MutableMapping):

    def __init__(self):
        self.by_hap_id = {}
        self.name_to_hap_id = {}

    # todos estos metodos son necesarios redefinit en un mutable mapping
    def __delitem__(self, hap_id):
        hap = self.by_hap_id.pop(hap_id)
        self.name_to_hap_id.pop(hap.name)

    def __getitem__(self, hap_id):
        return self.by_hap_id[hap_id]

    def __iter__(self):
        return iter(self.by_hap_id)

    def __len__(self):
        return len(self.by_hap_id)

    def __setitem__(self, hap_id, hap):
        self.by_hap_id[hap_id] = hap
        self.name_to_hap_id[hap.name] = hap_id

    def get_hap_id(self, name):
        return self.name_to_hap_id[name]


#===============================================================================
# PUT YOUR ETLs HERE
#===============================================================================

class ETL(etl.BaseETL):

    # you can access the current network from the attribute 'self.nw'
    # You can access all the allready created haplotypes from attribute
    # 'self.haplotypes_cache'. If you want to disable the cache put a class
    # level attribute 'HAPLOTYPES_CACHE = None'

    HAPLOTYPES_CACHE = DoubleDictCache

    def setup(self, filename):
        self.fp = open(filename, "w")
        self.name_to_hapid = {}
        self.fp.write(str(time.time()) + "\n")

    def teardown(self):
        self.fp.write(str(time.time()) + "\n")
        self.fp.close()

    def haplotype_gen(self):
        with open("haplotypes.csv") as fp:
            reader = csv.reader(fp)
            for row in reader:
                # no hace falta guardar la relacion name hap_id por que
                # se encarga el cache
                hap_id = row[0] # suponemos que el id esta en la primer columna
                name = row[1] # suponemos que la columna 1 tiene un atributo name
                yield dom.Haplotype(hap_id, name=name)

    def edge_gen(self):
        # combinamos de a dos haplotypos
        for hap0, hap1 in itertools.combinations(self.haplotypes_cache.values(), 2):
            w = weight.weight("hamming", hap0, hap1)
            haps_id = hap0.hap_id, hap1.hap_id
            yield dom.Edge(w, haps_id)

    def fact_gen(self):
        with open("facts.json", "rb") as fp:
            data = json.load(fp)
            for hap_name, facts_data in data.items():
                hap_id = self.haplotypes_cache.get_hap_id(hap_name)
                for fact_data in facts_data:
                    yield dom.Fact(hap_id, **fact_data)

    def handle_error(self, exc_type, exc_val, exc_tb):
        return exc_type == TypeError

#===============================================================================
# MAIN
#===============================================================================

if __name__ == "__main__":
    print(__doc__)

